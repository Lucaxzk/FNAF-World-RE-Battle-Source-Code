global.can_attack_sfx_variable = 0;

if (global.fightingS1 == 1) {
	global.fightingS1 = 0;
	global.animationS1 = 1;
	global.image_index_s1 = 1;
	if (global.slot1 == 1) {
		global.attack_verify = 1;
		instance_create_layer(global.slot1x, global.slot1y, "attacks", mic_toss);
		audio_play_sound(trow_sfx, 0, false);
	}
	
	if (global.slot1 == 2) {
		global.attack_verify = 1;
		instance_create_layer(192, 384, "attacks", bite_1);
	}
}