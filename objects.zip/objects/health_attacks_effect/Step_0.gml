if (verify == 0) {
	if (image_alpha >= 0.2) {
		image_alpha = 0.2;
		counter += 1
	}
}

if (verify == 0) {
	image_alpha += 0.05
}

if (verify == 1) {
	image_alpha -= 0.05
	can_destroy = 1;
}

if (counter >= 30) {
	verify = 1;
	counter = 0;
}

if (image_alpha <= 0) && (can_destroy == 1) {
	instance_destroy();
}