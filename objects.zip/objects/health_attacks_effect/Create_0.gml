image_alpha = 0;
image_xscale = 100;
image_yscale = 100;
verify = 0;
counter = 0;
can_destroy = 0;

if (global.attack_verify == 0) {
	instance_destroy();
}