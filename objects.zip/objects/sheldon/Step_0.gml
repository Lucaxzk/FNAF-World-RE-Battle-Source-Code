if (global.slot1 == 3) {
	if (global.slot1 == 3) {
		x = global.slot1x;
		y = global.slot1y;
	}
	
	//hace que valla al slot asignado

	if (global.hpS1 >= 1) {
		if (global.animationS1 == 1) {
			sprite_index = freddy_attack
		} else {
			sprite_index = sheldon_idle;
		}
	} else {
		sprite_index = missing_texture;
	}

	if (sprite_index == freddy_attack) {
		if (image_index >= 10) {
			global.animationS1 = 0;
		}
	}

	if (global.image_index_s1 == 1) {
		global.image_index_s1 = 0;
		image_index = 1;
	}
} else {
	instance_destroy();
}