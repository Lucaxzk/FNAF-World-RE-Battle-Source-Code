global.cslot3_x = 1000;
global.cslot3_y = 1000;