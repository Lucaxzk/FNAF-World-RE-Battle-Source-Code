x = global.cslot3_x;
y = global.cslot3_y;