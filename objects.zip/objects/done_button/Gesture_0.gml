if (global.slot1 != 0) {
	room_goto(game);
}