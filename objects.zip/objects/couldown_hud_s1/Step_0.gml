if (global.hpS1 >= 1) {
	sprite_index = couldown_hud_sprite
} else {
	sprite_index = couldown_hud_sprite_dead
}