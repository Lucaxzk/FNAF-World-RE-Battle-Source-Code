global.character_preview = 0; //0: nada 1: freddy 2: bonnie 3: sheldon
image_xscale = 1.25;
image_yscale = 1.25;