if (global.character_preview == 0) {
	sprite_index = -1;
}

if (global.character_preview == 1) {
	sprite_index = freddy_idle;
}

if (global.character_preview == 2) {
	sprite_index = bonnie_idle;
}

if (global.character_preview == 3) {
	sprite_index = sheldon_idle;
}