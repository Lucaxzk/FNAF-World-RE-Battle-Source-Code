global.fightingS1 = 0; //0: No esta peleando 1: Esta peleando 2: Esta muerto
global.slot1x = 0;
global.slot1y = 0;
global.animationS1 = 0;
global.couldownS1 = 0;

global.fightingS2 = 0; //0: No esta peleando 1: Esta peleando 2: Esta muerto
global.slot2x = 0;
global.slot2y = 0;
global.animationS2 = 0;
global.couldownS2 = 0;