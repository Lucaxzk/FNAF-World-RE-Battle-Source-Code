if (global.slot1 == 2) {
	if (global.slot1 == 2) {
		x = global.slot1x;
		y = global.slot1y;
	}
	
	//hace que valla al slot asignado

	if (global.hpS1 >= 1) {
		if (global.animationS1 == 1) {
			sprite_index = bonnie_attack
		} else {
			sprite_index = bonnie_idle;
		}
	} else {
		sprite_index = missing_texture;
	}

	if (sprite_index == bonnie_attack) {
		if (image_index >= 11) {
			global.animationS1 = 0;
		}
	}

	if (global.image_index_s1 == 1) {
		global.image_index_s1 = 0;
		image_index = 1;
	}
} else {
	instance_destroy();
}