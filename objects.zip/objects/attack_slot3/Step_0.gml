if (global.fightingS1 == 1) {
	image_alpha = 1;
	x = 736;
	if (global.slot1 == 1) {
	sprite_index = pizza_wheel_1_attack;
	}
	
	if (global.slot1 == 2) {
	sprite_index = regen_song_attack;
	}
	
	if (global.slot1 == 3) {
	sprite_index = jack_o_bomb_attack;
	}
} else {
	image_alpha = 0;
	x = 1000;
}