global.can_attack_sfx_variable = 0;

if (global.fightingS1 == 1) {
	global.fightingS1 = 0;
	global.animationS1 = 1;
	global.image_index_s1 = 1;
	if (global.slot1 == 1) {
		global.attack_verify = 1;
		global.pizza_wheel_1_counter += 6;
	}
	
	if (global.slot1 == 2) {
		global.attack_verify = 1;
		global.regen_song_counter += 6;
		instance_create_layer(0, 0, "attack_effects", health_attacks_effect);
		instance_create_layer(0, 0, "attacks", regen_song_health_controler);
	}
		
	if (global.slot1 == 3) {
		global.attack_verify = 1;
		global.jack_o_bomb_counter += 8;
	}
}