if (global.character_preview == 0) {
	image_alpha = 0;
} else {
	image_alpha = 1;
}

if (global.character_preview == 1) {
	sprite_index = instant_health_1_attack;
}

if (global.character_preview == 2) {
	sprite_index = bash_jam_attack;
}

if (global.character_preview == 3) {
	sprite_index = bazinga_attack;
}