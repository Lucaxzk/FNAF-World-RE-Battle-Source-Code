if (global.character_preview == 0) {
	image_alpha = 0;
} else {
	image_alpha = 1;
}

if (global.character_preview == 1) {
	sprite_index = pizza_wheel_1_attack;
}

if (global.character_preview == 2) {
	sprite_index = regen_song_attack;
}

if (global.character_preview == 3) {
	sprite_index = jack_o_bomb_attack;
}