global.enemy_couldownS3 += 1;

if (global.enemy_slot3 == 1) {
	sprite_index = geerrat_idle;
	
	if (global.enemy_couldownS3 >= 300) {
		instance_create_layer(1056, 384, "enemy_attacks", enemy_bite);
		global.enemy_couldownS3 = 0;
	
	}
}

if (global.enemy_hpS3 <= 0) {
	instance_destroy();
}

if (internal_hp > global.enemy_hpS3) {
	internal_hp = global.enemy_hpS3;
	damage_animation = 1;
}

if (damage_animation == 1) {
	image_alpha -= 0.2;
}

if (image_alpha <= 0) {
	damage_animation = 2;
}

if (damage_animation == 2) {
	if (image_alpha >= 1) {
		damage_animation = 0;
	} else {
		image_alpha += 0.2;
	}
}