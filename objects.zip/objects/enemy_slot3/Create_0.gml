global.enemy_couldownS3 = 0;
global.enemy_hpS3 = 0;
global.enemy_slot3 = irandom_range(1, 1)
internal_hp = 0;
damage_animation = 0;

if (global.enemy_slot3 == 1) {
	global.enemy_hpS3 = 90;
	internal_hp = 90;
}

if (global.game_mode == 2) {
	instance_destroy();
} else {
	
}