if (enemy_to_attack == 3) {
	instance_destroy();
	global.enemy_hpS3 -= 25
}