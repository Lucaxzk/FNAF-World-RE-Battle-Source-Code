if (destroy_for_out_room == 0) {
	audio_play_sound(mic_toss_damage_sfx, 0, false);
}