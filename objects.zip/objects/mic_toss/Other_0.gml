destroy_for_out_room = 1;
instance_destroy();