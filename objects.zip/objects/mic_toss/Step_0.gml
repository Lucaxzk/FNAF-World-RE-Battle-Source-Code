if (enemy_to_attack == 1) {
	if (object_exists(enemy_slot1)) {
		direction = 0;
		speed = -16;
	} else {
		enemy_to_attack = irandom_range(1, 4);
	}
}

if (enemy_to_attack == 2) {
	if (object_exists(enemy_slot2)) {
		direction = 20;
		speed = -16;
	} else {
		enemy_to_attack = irandom_range(1, 4);
	}
}

if (enemy_to_attack == 3) {
	if (object_exists(enemy_slot3)) {
		direction = 0;
		speed = -16;
	} else {
		enemy_to_attack = irandom_range(1, 4);
	}
}

if (enemy_to_attack == 4) {
	if (object_exists(enemy_slot4)) {
		direction = -20;
		speed = -16;
	} else {
		enemy_to_attack = irandom_range(1, 4);
	}
}

if (counter == 26) {
	if (global.attack_verify == 1) {
		speed = -16;	
		sprite_index = mic_toss_sprite;
	}
} else {
	speed = 0;
	sprite_index = -1;
}

if (counter >= 25) {
	counter = 26;
} else {
	counter += 1;
}