if (enemy_to_attack == 1) {
	instance_destroy();
	global.enemy_hpS1 -= 25
}