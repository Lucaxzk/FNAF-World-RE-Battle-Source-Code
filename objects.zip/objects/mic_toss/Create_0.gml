counter = 0;
destroy_for_out_room = 0;
enemy_to_attack = irandom_range(1, 4);

if (global.attack_verify == 1) {
	
}