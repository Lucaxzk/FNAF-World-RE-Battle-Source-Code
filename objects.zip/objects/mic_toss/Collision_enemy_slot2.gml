if (enemy_to_attack == 2) {
	instance_destroy();
	global.enemy_hpS2 -= 25
}