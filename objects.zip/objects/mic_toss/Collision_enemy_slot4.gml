if (enemy_to_attack == 4) {
	instance_destroy();
	global.enemy_hpS4 -= 25
}