counter = 0;
counter_to_destroy = 0;