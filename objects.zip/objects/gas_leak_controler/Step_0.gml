counter += 1;

if (counter >= 60) {
	counter = 0;
	counter_to_destroy += 1;
	if (variable_global_exists("enemy_hpS1")) {
		global.enemy_hpS1 -= 4;
		global.enemy_hpS2 -= 4;
		global.enemy_hpS3 -= 4;
		global.enemy_hpS4 -= 4;
	}
}

if (counter_to_destroy >= 6) {
	instance_destroy();
}