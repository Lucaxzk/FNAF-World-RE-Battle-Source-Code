global.slot1x = x
global.slot1y = y
global.couldownS1 = counter;

if (global.fightingS1 == 1) && (global.hpS1 >= 1) {
	counter = 0;
} else {
	counter += 1;
}

//controlador del contador interno, fah ni idea ya me olvide que hacia


if (global.hpS1 <= 0) {
	if (slotDead == 0) {
		slotDead = 1;
		instance_create_layer(x, y, "effects", death_slot);
	}
	global.fightingS1 = 0;
} else {
	slotDead = 0;
}

//Comprueba si el slot esta muerto, si ese es el caso el fighting del slot no estara disponible a menos que sea revivido

if (global.slot1 == 1) {
	if (counter >= 300) && (global.fightingS1 == 0) {
		global.fightingS1 = 1;
	}
}
	
//Si no esta atacando y el slot esta vivo se suma 1 a counter hasta llegar 300

if (global.hpS1 <= 0) {
	global.fightingS1 = 2;
	counter = 0;
}
	
//Si el slot esta muerto se desactivan todos sus controladores

if (global.fightingS1 == 2) {
	counter = 0;
}
	
//si el jugador esta muerto, el contador nunca podra avanzar

if (global.slot1 == 1) {
	if (global.hpS1 >= 151) {
		global.hpS1 = 150;
	}
}

//Si cierto personaje supera su vida maxima la resetea a al minimo

//codigo de freddy

if (global.hpS1 <= 0) {
	slotDead = 1;
	global.fightingS1 = 0;
} else {
	slotDead = 0;
}

//Comprueba si el slot esta muerto, si ese es el caso el fighting del slot no estara disponible a menos que sea revivido

if (global.slot1 == 2) {
	if (counter >= 300) && (global.fightingS1 == 0) {
		global.fightingS1 = 1;
	}
}
	
//Si no esta atacando y el slot esta vivo se suma 1 a counter hasta llegar 300

if (global.hpS1 <= 0) {
	global.fightingS1 = 2;
	counter = 0;
}
	
//Si el slot esta muerto se desactivan todos sus controladores

if (global.fightingS1 == 2) {
	counter = 0;
}
	
//si el jugador esta muerto, el contador nunca podra avanzar
	


if (global.slot1 == 2) {
	if (global.hpS1 >= 151) {
		global.hpS1 = 150;
	}
}

//Si cierto personaje supera su vida maxima la resetea a al minimo

//Codigo de bonnie

if (global.hpS1 <= 0) {
	slotDead = 1;
	global.fightingS1 = 0;
} else {
	slotDead = 0;
}

//Comprueba si el slot esta muerto, si ese es el caso el fighting del slot no estara disponible a menos que sea revivido

if (global.slot1 == 3) {
	if (counter >= 300) && (global.fightingS1 == 0) {
		global.fightingS1 = 1;
	}
}
	
//Si no esta atacando y el slot esta vivo se suma 1 a counter hasta llegar 300

if (global.hpS1 <= 0) {
	global.fightingS1 = 2;
	counter = 0;
}
	
//Si el slot esta muerto se desactivan todos sus controladores

if (global.fightingS1 == 2) {
	counter = 0;
}
	
//si el jugador esta muerto, el contador nunca podra avanzar
	


if (global.slot1 == 3) {
	if (global.hpS1 >= 170) {
		global.hpS1 = 169;
	}
}

//Si cierto personaje supera su vida maxima la resetea a al minimo

//Codigo de sheldon