slotDead = 0; //0: Vivo 1: Muerto
counter = 0;

if (global.slot1 == 1) { //el 1 es freddy
	global.hpS1 = 150;
}

if (global.slot1 == 2) { //el 2 es bonnie
	global.hpS1 = 150;
}

if (global.slot1 == 3) { //el 3 es sheldon
	global.hpS1 = 169;
}

//El código lo que hace es que si el slot es cierto personaje se le pone la vida de ese personajes