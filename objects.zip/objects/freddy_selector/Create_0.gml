global.character_preview = 0;
global.cslot1_x = 100000
global.cslot1_y = 100000
global.cslot2_x = 1000;
global.cslot2_y = 1000;
global.cslot3_x = 1000;
global.cslot3_y = 1000;