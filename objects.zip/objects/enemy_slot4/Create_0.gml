global.enemy_couldownS4 = 0;
global.enemy_hpS4 = 0;
global.enemy_slot4 = irandom_range(1, 1)
internal_hp = 0;
damage_animation = 0;

if (global.enemy_slot4 == 1) {
	global.enemy_hpS4 = 90;
	internal_hp = 90;
}

if (global.game_mode == 2) {
	instance_destroy();
} else {
	
}