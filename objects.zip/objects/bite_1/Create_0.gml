sprite_index = bite_1_sprite;
image_index = 1;
image_xscale = 1.25;
image_yscale = 1.25;