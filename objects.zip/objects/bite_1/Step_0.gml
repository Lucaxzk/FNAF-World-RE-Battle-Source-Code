if (image_index >= 8) {
	if (variable_global_exists("enemy_hpS1")) {
    global.enemy_hpS1 -= irandom_range(20, 25);
	global.enemy_hpS2 -= irandom_range(20, 25);
	global.enemy_hpS3 -= irandom_range(20, 25);
	global.enemy_hpS4 -= irandom_range(20, 25);
	}
	instance_destroy();
}