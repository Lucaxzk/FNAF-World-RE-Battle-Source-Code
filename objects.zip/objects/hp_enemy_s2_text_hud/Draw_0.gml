if (global.enemy_slot2 == 0) {
	draw_set_halign(fa_center);
	draw_set_valign(fa_middle);
	draw_text_transformed(x, y, "", 3, 3, 0)
	draw_set_halign(fa_left);
	draw_set_valign(fa_top);
} else {
	if (global.enemy_hpS2 >= 1) {
		draw_set_halign(fa_center);
		draw_set_valign(fa_middle);
		draw_text_transformed(x, y, global.enemy_hpS2, 3, 3, 0)
		draw_set_halign(fa_left);
		draw_set_valign(fa_top);
	} else {
		draw_set_halign(fa_center);
		draw_set_valign(fa_middle);
		draw_text_transformed(x, y, "X", 3, 3, 0)
		draw_set_halign(fa_left);
		draw_set_valign(fa_top);
	}
}