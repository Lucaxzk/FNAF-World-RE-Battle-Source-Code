if (global.hpS1 >= 1) {
	sprite_index = hp_hud_sprite
} else {
	sprite_index = hp_hud_sprite_dead
}