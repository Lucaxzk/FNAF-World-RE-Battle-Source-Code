draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_text_transformed(x, y, global.hpS1, 3, 3, 0)
draw_set_halign(fa_left);
draw_set_valign(fa_top);