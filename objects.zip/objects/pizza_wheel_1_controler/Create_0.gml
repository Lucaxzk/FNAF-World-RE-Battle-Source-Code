global.pizza_wheel_1_counter = 0;
counter = 0;