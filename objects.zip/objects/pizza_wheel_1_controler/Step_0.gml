counter += 1;

if (counter >= 30) {
	if (global.pizza_wheel_1_counter >= 1) {
		if (variable_global_exists("pizza_wheel_1_counter")) {
			global.pizza_wheel_1_counter -= 1;
			instance_create_layer(global.slot1x, global.slot1y, "attacks", pizza_wheel_1);
			counter = 0;
		}
	}
}