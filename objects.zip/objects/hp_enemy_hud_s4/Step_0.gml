if (global.enemy_slot4 == 0) {
	sprite_index = -1;
} else {
	if (global.enemy_hpS4 >= 1) {
		sprite_index = hp_hud_sprite
	} else {
		sprite_index = hp_hud_sprite_dead
	}
}