if (global.enemy_slot1 == 0) {
	sprite_index = -1
} else {
	if (global.enemy_hpS1 >= 1) {
		sprite_index = couldown_hud_sprite
	} else {
		sprite_index = couldown_hud_sprite_dead
	}
}