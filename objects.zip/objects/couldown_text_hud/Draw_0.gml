if (global.couldownS1 >= 1) && (global.couldownS1 <= 60) {
	draw_text_transformed(x, y, "5", 3, 3, 0)
}

if (global.couldownS1 >= 61) && (global.couldownS1 <= 120) {
	draw_text_transformed(x, y, "4", 3, 3, 0)
}

if (global.couldownS1 >= 121) && (global.couldownS1 <= 180) {
	draw_text_transformed(x, y, "3", 3, 3, 0)
}

if (global.couldownS1 >= 181) && (global.couldownS1 <= 240) {
	draw_text_transformed(x, y, "2", 3, 3, 0)
}

if (global.couldownS1 >= 241) && (global.couldownS1 <= 300) {
	draw_text_transformed(x, y, "1", 3, 3, 0)
}

if (global.couldownS1 == 0) {
	draw_text_transformed(x, y, "0", 3, 3, 0)
}