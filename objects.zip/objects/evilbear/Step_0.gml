x = global.boss_x;
y = 320