global.boss_x = 0;
global.boss_y = 0;
image_xscale = 1.5;
image_yscale = 1.5;

if (variable_global_exists("boss_slot")) {
	if (global.boss_slot == 1) {
		
	} else {
		instance_destroy();
	}
}