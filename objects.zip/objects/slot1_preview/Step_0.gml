if (variable_global_exists("slot1")) {
	if (global.slot1 == 0) {
		sprite_index = -1;
	}
	
	if (global.slot1 == 1) {
		sprite_index = freddy_idle;
	}
	
	if (global.slot1 == 2) {
		sprite_index = bonnie_idle;
	}
	
	if (global.slot1 == 3) {
		sprite_index = sheldon_idle;
	}
}