global.regen_song_counter = 0;
counter = 0;