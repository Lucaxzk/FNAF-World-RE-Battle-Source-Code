counter += 1;

if (counter >= 15) {
	if (global.regen_song_counter >= 1) {
		if (variable_global_exists("regen_song_counter")) {
			global.regen_song_counter -= 1;
			instance_create_layer(global.slot1x, global.slot1y, "attacks", regen_song);
			counter = 0;
		}
	}
}