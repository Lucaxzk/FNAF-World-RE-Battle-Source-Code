counter += 1;

if (counter >= 20) {
	if (global.jack_o_bomb_counter >= 1) {
		if (variable_global_exists("jack_o_bomb_counter")) {
			global.jack_o_bomb_counter -= 1;
			instance_create_layer(x, y, "attacks", jack_o_bomb);
			counter = 0;
		}
	}
}