global.jack_o_bomb_counter = 0;
counter = 0;