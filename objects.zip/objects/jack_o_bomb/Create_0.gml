x = irandom_range(800, 992);
y = -64;
counter = 0;
can_make_damage = 0;

if (global.attack_verify == 0) {
	instance_destroy();
}