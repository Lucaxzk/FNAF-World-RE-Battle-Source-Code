if (can_make_damage == 1) {
	global.enemy_hpS1 -= irandom_range(3, 5);
	global.enemy_hpS2 -= irandom_range(3, 5);
	global.enemy_hpS3 -= irandom_range(3, 5);
	global.enemy_hpS4 -= irandom_range(3, 5);
}