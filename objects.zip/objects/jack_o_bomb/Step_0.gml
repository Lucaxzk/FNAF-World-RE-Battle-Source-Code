x -= 5;
y += 5;
counter += 1;

if (counter >= 1) {
	can_make_damage = 1;
}

if (y >= 480) {
	instance_destroy();
}