if (global.fightingS1 == 1) {
	image_alpha = 1;
	x = 736;
	if (global.slot1 == 1) {
	sprite_index = instant_health_1_attack;
	}
	
	if (global.slot1 == 2) {
	sprite_index = bash_jam_attack;
	}
	
	if (global.slot1 == 3) {
	sprite_index = bazinga_attack;
	}
} else {
	image_alpha = 0;
	x = 1000;
}