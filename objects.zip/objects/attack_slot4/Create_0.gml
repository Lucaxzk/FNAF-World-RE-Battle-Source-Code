global.fightingS1 = 0;
image_xscale = 0.3;
image_yscale = 0.3;
global.animationS1 = 0;
global.image_index_s1 = 0;
global.attack_verify = 0;
global.bash_jam_counter = 0;