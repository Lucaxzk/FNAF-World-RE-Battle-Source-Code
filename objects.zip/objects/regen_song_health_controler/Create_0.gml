if (variable_global_exists("hpS1")) {
    global.hpS1 += 7;
}
counter = 60;
counter_to_destroy = 0;