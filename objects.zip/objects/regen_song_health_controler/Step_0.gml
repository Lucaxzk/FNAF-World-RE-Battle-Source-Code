counter += 1;

if (counter >= 60) {
	counter = 0;
	counter_to_destroy += 1;
	if (variable_global_exists("hpS1")) {
		global.hpS1 += 7;
	}
}

if (counter_to_destroy >= 6) {
	instance_destroy();
}