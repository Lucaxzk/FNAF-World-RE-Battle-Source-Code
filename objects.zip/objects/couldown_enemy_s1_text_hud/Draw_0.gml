if (global.enemy_slot1 == 0) {
	draw_text_transformed(x, y, "", 3, 3, 0)
} else {
	if (global.enemy_hpS1 >= 1) {
		if (global.enemy_couldownS1 >= 1) && (global.enemy_couldownS1 <= 60) {
		draw_text_transformed(x, y, "6", 3, 3, 0)
		}

		if (global.enemy_couldownS1 >= 61) && (global.enemy_couldownS1 <= 120) {
			draw_text_transformed(x, y, "5", 3, 3, 0)
		}

		if (global.enemy_couldownS1 >= 121) && (global.enemy_couldownS1 <= 180) {
			draw_text_transformed(x, y, "4", 3, 3, 0)
		}

		if (global.enemy_couldownS1 >= 181) && (global.enemy_couldownS1 <= 240) {
			draw_text_transformed(x, y, "3", 3, 3, 0)
		}

		if (global.enemy_couldownS1 >= 241) && (global.enemy_couldownS1 <= 300) {
			draw_text_transformed(x, y, "2", 3, 3, 0)
		}
		
		if (global.enemy_couldownS1 >= 301) && (global.enemy_couldownS1 <= 360) {
			draw_text_transformed(x, y, "1", 3, 3, 0)
		}

		if (global.enemy_couldownS1 == 0) {
			draw_text_transformed(x, y, "0", 3, 3, 0)
		}
	} else {
		draw_text_transformed(x, y, "X", 3, 3, 0)
	}
}