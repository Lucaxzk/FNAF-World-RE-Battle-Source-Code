global.slot1 = 0;
global.slot2 = 0;
global.slot3 = 0;