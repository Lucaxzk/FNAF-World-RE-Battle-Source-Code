if (variable_global_exists("slot3")) {
	if (global.slot3 == 0) {
		sprite_index = -1;
	}
	
	if (global.slot3 == 1) {
		sprite_index = freddy_idle;
	}
	
	if (global.slot3 == 2) {
		sprite_index = bonnie_idle;
	}
	
	if (global.slot3 == 3) {
		sprite_index = sheldon_idle;
	}
}