global.cslot1_x = 1000;
global.cslot1_y = 1000;