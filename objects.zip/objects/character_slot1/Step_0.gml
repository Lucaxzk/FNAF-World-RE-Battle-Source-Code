x = global.cslot1_x;
y = global.cslot1_y;