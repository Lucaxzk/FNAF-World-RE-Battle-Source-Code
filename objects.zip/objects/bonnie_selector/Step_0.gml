if (position_meeting(mouse_x, mouse_y, bonnie_selector)) {
	global.character_preview = 2;
}
if (global.slot1 == 2) {
	global.cslot1_x = x
	global.cslot1_y = y
}

if (global.slot1 == 0) {
	global.cslot1_x = 10000
	global.cslot1_y = 10000
}

if (global.slot2 == 2) {
	global.cslot2_x = x
	global.cslot2_y = y
}

if (global.slot2 == 0) {
	global.cslot2_x = 10000
	global.cslot2_y = 10000
}

if (global.slot3 == 2) {
	global.cslot3_x = x
	global.cslot3_y = y
}

if (global.slot3 == 0) {
	global.cslot3_x = 10000
	global.cslot3_y = 10000
}