if (global.slot1 == 0) {
	global.slot1 = 2;
} else {
	if (global.slot2 == 0) {
	global.slot2 = 2;
	} else {
		if (global.slot3 == 0) {
		global.slot3= 2;
		}
	}
}