room_goto(party_creation)
global.game_mode = 2;
global.slot1 = 0;
global.cslot2_x = 1000;
global.cslot2_y = 1000;
global.slot2 = 0;
global.cslot3_x = 1000;
global.cslot3_y = 1000;
global.slot3 = 0;