global.enemy_couldownS1 = 0;
global.enemy_hpS1 = 0;
global.enemy_slot1 = irandom_range(1, 1)
internal_hp = 0;
image_alpha = 1;
damage_animation = 0;

if (global.enemy_slot1 == 1) {
	global.enemy_hpS1 = 90;
	internal_hp = 90;
}

if (global.game_mode == 2) {
	instance_destroy();
} else {
	
}