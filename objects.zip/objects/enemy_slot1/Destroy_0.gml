if (global.game_mode == 1) {
	instance_create_layer(x, y, "effects", death_slot);
	instance_create_layer(x, y, "enemy_slots", enemy_slot1);
}