if (counter >= 1) {
	counter += 1
}

if (counter >= 30) {
	instance_destroy();
}