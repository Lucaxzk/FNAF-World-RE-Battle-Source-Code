counter += 1;

if (counter >= 20) {
	if (global.bash_jam_counter >= 1) {
		if (variable_global_exists("pizza_wheel_1_counter")) {
			global.bash_jam_counter -= 1;
			instance_create_layer(global.slot1x, global.slot1y, "attacks", bash_jam);
			counter = 0;
		}
	}
}