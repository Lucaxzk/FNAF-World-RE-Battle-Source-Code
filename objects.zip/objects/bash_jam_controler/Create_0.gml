global.bash_jam_counter = 0;
counter = 0;
can_make_damage = 1;