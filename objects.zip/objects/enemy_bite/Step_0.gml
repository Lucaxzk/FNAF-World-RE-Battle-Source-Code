if (image_index >= 8) {
	if (variable_global_exists("hpS1")) {
    global.hpS1 -= 10;
	}
	instance_destroy();
}