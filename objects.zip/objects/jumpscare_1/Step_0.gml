x_anim = x;
y_anim = y;

if (image_xscale < 0.6) {
	image_xscale += 0.05;
	image_yscale += 0.05;
}

if (image_alpha < 1) {
	image_alpha += 0.1;
}

counter += 1;
if (global.attack_verify == 1) {
	if (counter >= 60) {
		instance_destroy();
		global.attack_verify = 0;
	}
}

x = x_anim + irandom_range(-2, 2);
y = y_anim + irandom_range(-2, 2);