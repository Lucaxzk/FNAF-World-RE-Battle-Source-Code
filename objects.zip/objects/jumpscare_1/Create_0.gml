counter = 0;
image_xscale = 0.3;
image_yscale = 0.3;
image_alpha = 0;
x_anim = x;
y_anim = y;

if (variable_global_exists("enemy_hpS1")) {
    global.enemy_hpS1 -= 100;
	global.enemy_hpS2 -= 100;
	global.enemy_hpS3 -= 100;
	global.enemy_hpS4 -= 100;
}

if (global.attack_verify == 1) {
	audio_play_sound(jumpscare_1_sfx, 0, false);
}