global.boss_couldown = 0;
global.boss_hp = 0;
internal_hp = 0;
image_alpha = 1;
damage_animation = 0;
image_xscale = 1.5;
image_yscale = 1.5;
global.boss_x = 0;
global.boss_y = 0;

if (global.game_mode == 2) {
	global.boss_slot = irandom_range(1, 1)
} else {
	instance_destroy();
}

if (global.boss_slot == 1) {
	global.boss_hp = 190;
	internal_hp = 190;
}