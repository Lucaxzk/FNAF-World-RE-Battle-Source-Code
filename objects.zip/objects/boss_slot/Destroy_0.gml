if (global.game_mode == 1) {
	
} else {
	instance_create_layer(x, y, "effects", death_slot);
}