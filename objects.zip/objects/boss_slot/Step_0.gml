global.boss_couldown += 1;
global.boss_x = x;
global.boss_y = y;

if (global.boss_hp <= 0) {
	instance_destroy();
}

if (global.boss_slot == 1) {
	if (global.boss_couldown >= 360) {
		instance_create_layer(1056, 384, "enemy_attacks", enemy_bite);
		global.boss_couldown = 0;
	
	}
}

if (internal_hp > global.boss_hp) {
	internal_hp = global.boss_hp;
	damage_animation = 1;
}

if (damage_animation == 1) {
	image_alpha -= 0.2;
}

if (image_alpha <= 0) {
	damage_animation = 2;
}

if (damage_animation == 2) {
	if (image_alpha >= 1) {
		damage_animation = 0;
	} else {
		image_alpha += 0.2;
	}
}