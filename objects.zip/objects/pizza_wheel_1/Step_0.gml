speed = -10;
counter += 1;

if (x <= 288) {
	if (variable_global_exists("enemy_hpS1")) {
		if (can_make_damage == 1) {
			global.enemy_hpS1 -= irandom_range(5, 7);
			global.enemy_hpS2 -= irandom_range(5, 7);
			global.enemy_hpS3 -= irandom_range(5, 7);
			global.enemy_hpS4 -= irandom_range(5, 7);
			can_make_damage = 0;
			audio_play_sound(pizza_1_damage_sfx, 0, false);
		}
	}
}