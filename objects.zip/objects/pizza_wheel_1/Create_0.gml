y = irandom_range(128, 640);
x = 1760;
image_xscale = 2;
image_yscale = 2;
can_make_damage = 1;
counter = 0;

if (global.attack_verify == 0) {
	instance_destroy();
}