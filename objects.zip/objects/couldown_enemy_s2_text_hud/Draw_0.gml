if (global.enemy_slot2 == 0) {
	draw_text_transformed(x, y, "", 3, 3, 0)
} else {
	if (global.enemy_hpS2 >= 1) {
		if (global.enemy_couldownS2 >= 1) && (global.enemy_couldownS2 <= 60) {
		draw_text_transformed(x, y, "7", 3, 3, 0)
		}

		if (global.enemy_couldownS2 >= 61) && (global.enemy_couldownS2 <= 120) {
			draw_text_transformed(x, y, "6", 3, 3, 0)
		}

		if (global.enemy_couldownS2 >= 121) && (global.enemy_couldownS2 <= 180) {
			draw_text_transformed(x, y, "5", 3, 3, 0)
		}

		if (global.enemy_couldownS2 >= 181) && (global.enemy_couldownS2 <= 240) {
			draw_text_transformed(x, y, "4", 3, 3, 0)
		}

		if (global.enemy_couldownS2 >= 241) && (global.enemy_couldownS2 <= 300) {
			draw_text_transformed(x, y, "3", 3, 3, 0)
		}
		
		if (global.enemy_couldownS2 >= 301) && (global.enemy_couldownS2 <= 360) {
			draw_text_transformed(x, y, "2", 3, 3, 0)
		}
		if (global.enemy_couldownS2 >= 361) && (global.enemy_couldownS2 <= 420) {
			draw_text_transformed(x, y, "1", 3, 3, 0)
		}

		if (global.enemy_couldownS2 == 0) {
			draw_text_transformed(x, y, "0", 3, 3, 0)
		}
	} else {
		draw_text_transformed(x, y, "X", 3, 3, 0)
	}
}