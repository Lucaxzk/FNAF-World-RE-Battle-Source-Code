y = -64
x = irandom_range(832, 1216);
counter = 0;
scale = irandom_range(0.9, 1.1);

if (global.attack_verify == 0) {
	instance_destroy();
}