counter += 1;
image_yscale = scale;
image_xscale = scale;

if (y >= 448) {
	
} else {
	y += 16;
}

if (counter >= 420) {
	instance_destroy();
}