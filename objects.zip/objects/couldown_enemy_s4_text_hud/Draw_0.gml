if (global.enemy_slot4 == 0) {
	draw_text_transformed(x, y, "", 3, 3, 0)
} else {
	if (global.enemy_hpS4 >= 1) {
		if (global.enemy_couldownS4 >= 1) && (global.enemy_couldownS4 <= 60) {
		draw_text_transformed(x, y, "8", 3, 3, 0)
		}

		if (global.enemy_couldownS4 >= 61) && (global.enemy_couldownS4 <= 120) {
			draw_text_transformed(x, y, "7", 3, 3, 0)
		}

		if (global.enemy_couldownS4 >= 121) && (global.enemy_couldownS4 <= 180) {
			draw_text_transformed(x, y, "6", 3, 3, 0)
		}

		if (global.enemy_couldownS4 >= 181) && (global.enemy_couldownS4 <= 240) {
			draw_text_transformed(x, y, "5", 3, 3, 0)
		}

		if (global.enemy_couldownS4 >= 241) && (global.enemy_couldownS4 <= 300) {
			draw_text_transformed(x, y, "4", 3, 3, 0)
		}
		
		if (global.enemy_couldownS4 >= 301) && (global.enemy_couldownS4 <= 360) {
			draw_text_transformed(x, y, "3", 3, 3, 0)
		}
		
		if (global.enemy_couldownS4 >= 361) && (global.enemy_couldownS4 <= 420) {
			draw_text_transformed(x, y, "2", 3, 3, 0)
		}
		
		if (global.enemy_couldownS4 >= 421) && (global.enemy_couldownS4 <= 480) {
			draw_text_transformed(x, y, "1", 3, 3, 0)
		}

		if (global.enemy_couldownS4 == 0) {
			draw_text_transformed(x, y, "0", 3, 3, 0)
		}
	} else {
		draw_text_transformed(x, y, "X", 3, 3, 0)
	}
}