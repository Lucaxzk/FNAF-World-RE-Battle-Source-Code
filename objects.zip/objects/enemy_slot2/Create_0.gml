global.enemy_couldownS2 = 0;
global.enemy_hpS2 = 0;
global.enemy_slot2 = irandom_range(1, 1)
damage_animation = 0;
internal_hp = 0;

if (global.enemy_slot2 == 1) {
	global.enemy_hpS2 = 90;
	internal_hp = 90;
}

if (global.game_mode == 2) {
	instance_destroy();
} else {
	
}