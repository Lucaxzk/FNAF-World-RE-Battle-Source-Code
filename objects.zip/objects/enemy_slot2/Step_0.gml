global.enemy_couldownS2 += 1;

if (global.enemy_slot2 == 1) {
	sprite_index = geerrat_idle;
	
	if (global.enemy_couldownS2 >= 420) {
		instance_create_layer(1056, 384, "enemy_attacks", enemy_bite);
		global.enemy_couldownS2 = 0;
	
	}
}

if (global.enemy_hpS2 <= 0) {
	instance_destroy();
}

if (internal_hp > global.enemy_hpS2) {
	internal_hp = global.enemy_hpS2;
	damage_animation = 1;
}

if (damage_animation == 1) {
	image_alpha -= 0.2;
}

if (image_alpha <= 0) {
	damage_animation = 2;
}

if (damage_animation == 2) {
	if (image_alpha >= 1) {
		damage_animation = 0;
	} else {
		image_alpha += 0.2;
	}
}