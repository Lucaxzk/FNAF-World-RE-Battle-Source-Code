global.can_attack_sfx_variable = 0;

if (global.fightingS1 == 1) {
	global.fightingS1 = 0;
	global.animationS1 = 1;
	global.image_index_s1 = 1;
	if (global.slot1 == 1) {
		global.attack_verify = 1;
		instance_create_layer(683, 384, "attacks", jumpscare_1);
	}
	
	if (global.slot1 == 2) {
		global.attack_verify = 1;
		instance_create_layer(683, 384, "attacks", jumpscare_1);
	}
	
	if (global.slot1 == 3) {
		global.attack_verify = 1;
		instance_create_layer(0, 0, "attack_effects", health_attacks_effect);
		instance_create_layer(0, 0, "attacks", gas_leak_controler);
	}
}