if (global.fightingS1 == 1) {
	image_alpha = 1;
	x = 736;
	if (global.slot1 == 1) {
	sprite_index = jumpscare_1_attack;
	}
	
	if (global.slot1 == 2) {
	sprite_index = jumpscare_1_attack;
	}
	
	if (global.slot1 == 3) {
	sprite_index = gas_leak_attack;
	}
} else {
	image_alpha = 0;
	x = 1000;
}

if (global.fightingS1 == 1) {
	if (global.can_attack_sfx_variable == 0) {
		audio_play_sound(can_attack_sfx, 0, false);
		global.can_attack_sfx_variable = 1;
	}
}