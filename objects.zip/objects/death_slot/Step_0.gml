if (image_index >= 6) {
	image_index = 6;
}

counter += 1;

if (counter >= 30) {
	image_alpha -= 0.1
}

if (image_alpha <= 0) {
	instance_destroy();
}