if (global.enemy_slot3 == 0) {
	draw_text_transformed(x, y, "", 3, 3, 0)
} else {
	if (global.enemy_hpS3 >= 1) {
		if (global.enemy_couldownS3 >= 1) && (global.enemy_couldownS3 <= 60) {
		draw_text_transformed(x, y, "5", 3, 3, 0)
		}

		if (global.enemy_couldownS3 >= 61) && (global.enemy_couldownS3 <= 120) {
			draw_text_transformed(x, y, "4", 3, 3, 0)
		}

		if (global.enemy_couldownS3 >= 121) && (global.enemy_couldownS3 <= 180) {
			draw_text_transformed(x, y, "3", 3, 3, 0)
		}

		if (global.enemy_couldownS3 >= 181) && (global.enemy_couldownS3 <= 240) {
			draw_text_transformed(x, y, "2", 3, 3, 0)
		}

		if (global.enemy_couldownS3 >= 241) && (global.enemy_couldownS3 <= 300) {
			draw_text_transformed(x, y, "1", 3, 3, 0)
		}

		if (global.enemy_couldownS3 == 0) {
			draw_text_transformed(x, y, "0", 3, 3, 0)
		}
	} else {
		draw_text_transformed(x, y, "X", 3, 3, 0)
	}
}