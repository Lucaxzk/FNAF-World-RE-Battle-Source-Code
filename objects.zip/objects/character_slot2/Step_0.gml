x = global.cslot2_x;
y = global.cslot2_y;