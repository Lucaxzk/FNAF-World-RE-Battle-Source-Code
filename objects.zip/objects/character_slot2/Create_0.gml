global.cslot2_x = 1000;
global.cslot2_y = 1000;