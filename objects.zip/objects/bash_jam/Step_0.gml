y -= 4

if (animation_go == 1) {
	x += 8
}

if (x >= 352) {
	animation_go = 2;
}

if (animation_go == 2) {
	x -= 8
}

if (x <= 160) {
	animation_go = 1;
}

if (y <= -64) {
	instance_destroy();
}

if (y == 384) {
	if (variable_global_exists("enemy_hpS1")) {
		if (can_make_damage == 1) {
			global.enemy_hpS1 -= irandom_range(1, 2);
			global.enemy_hpS2 -= irandom_range(1, 2);
			global.enemy_hpS3 -= irandom_range(1, 2);
			global.enemy_hpS4 -= irandom_range(1, 2);
			can_make_damage = 0;
		}
	}
}