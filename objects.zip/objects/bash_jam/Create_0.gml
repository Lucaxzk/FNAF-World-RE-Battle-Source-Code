x = 256;
y = 832;
animation_go = 1; //1: derecha 2:izquierda
can_make_damage = 1;

if (global.attack_verify == 0) {
	instance_destroy();
}