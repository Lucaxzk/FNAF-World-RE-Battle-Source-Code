if (room == team_preview) {
	room_goto(party_creation);
}

if (room == party_creation) {
	room_goto(choose_game_mode);
}

if (room == choose_game_mode) {
	room_goto(menu);
}

if (room == menu) {
	room_goto(tittle_screen);
}