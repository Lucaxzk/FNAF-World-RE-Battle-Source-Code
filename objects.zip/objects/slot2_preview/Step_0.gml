if (variable_global_exists("slot2")) {
	if (global.slot2 == 0) {
		sprite_index = -1;
	}
	
	if (global.slot2 == 1) {
		sprite_index = freddy_idle;
	}
	
	if (global.slot2 == 2) {
		sprite_index = bonnie_idle;
	}
	
	if (global.slot2 == 3) {
		sprite_index = sheldon_idle;
	}
}